package com.deloitte.base.domain.repository

interface PreferencesRepository {

}