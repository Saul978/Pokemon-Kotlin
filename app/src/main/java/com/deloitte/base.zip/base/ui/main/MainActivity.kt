package com.deloitte.base.ui.main

import com.deloitte.base.databinding.ActivityMainBinding
import com.deloitte.base.ui.base.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : BaseActivity<ActivityMainBinding, MainViewModel>() {

    override fun getViewBinding() = ActivityMainBinding.inflate(layoutInflater)

    private var mainViewModel: MainViewModel? = null

    override fun initViewModel() {
        mainViewModel = getActivityViewModel(MainViewModel::class.java)
    }
}