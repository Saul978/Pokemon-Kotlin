package com.deloitte.base.ui.main

import com.deloitte.base.ui.base.BaseViewModel

class MainViewModel: BaseViewModel() {
}