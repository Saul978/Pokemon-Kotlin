package com.deloitte.base.ui.list

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.deloitte.base.domain.entity.PokemonEntity
import com.deloitte.base.domain.usecases.GetPokemonUseCase
import com.deloitte.base.ui.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class ListViewModel @Inject constructor(private val getPokemonUseCase: GetPokemonUseCase): BaseViewModel() {

}