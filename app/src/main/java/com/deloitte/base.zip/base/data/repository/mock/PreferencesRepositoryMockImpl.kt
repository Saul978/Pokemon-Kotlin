package com.deloitte.base.data.repository.mock

import com.deloitte.base.domain.repository.PreferencesRepository

class PreferencesRepositoryMockImpl : PreferencesRepository {

}