package com.deloitte.base.di.module

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import com.deloitte.base.App
import com.deloitte.base.data.api.Api
import com.deloitte.base.data.factory.ApiRepositoryFactory
import com.deloitte.base.data.repository.mock.ApiRepositoryMockImpl
import com.deloitte.base.data.repository.mock.PreferencesRepositoryMockImpl
import com.deloitte.base.data.repository.network.ApiRepositoryNetworkImpl
import com.deloitte.base.data.repository.persistence.PreferencesRepositoryPreferencesImpl
import com.deloitte.base.utils.Constants
import com.example.msspa_megusta_library.data.factory.PreferenceRepositoryFactory
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetModule {

    @Provides
    @Singleton
    fun provideApiRepositoryFactory(
        api: Api
    ): ApiRepositoryFactory =
        ApiRepositoryFactory(
            ApiRepositoryMockImpl(), ApiRepositoryNetworkImpl(api)
        )

    @Provides
    fun provideGson(): Gson =
        GsonBuilder().create()

    @Named("okHttpClient")
    @Provides
    fun provideOkHttpClient(
        httpLoggingInterceptor: HttpLoggingInterceptor
    ): OkHttpClient =
        OkHttpClient.Builder()
            .connectTimeout(
                Constants.General.HTTP_CONNECT_TIMEOUT,
                TimeUnit.MILLISECONDS
            )
            .readTimeout(Constants.General.HTTP_READ_TIMEOUT, TimeUnit.MILLISECONDS)
            .addInterceptor(httpLoggingInterceptor)
            .build()

    @Provides
    fun provideHttpLoggingInterceptor(): HttpLoggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    @Provides
    fun provideRetrofit(
        gson: Gson,
        @Named("okHttpClient") okHttpClient: OkHttpClient
    ): Retrofit =
        Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .baseUrl(Constants.Api.URL_API)
            .client(okHttpClient)
            .build()


    @Provides
    fun provideApiService(
        retrofit: Retrofit,
        @Named("okHttpClient") okHttpClient: OkHttpClient
    ): Api = retrofit.newBuilder().client(okHttpClient).build().create(Api::class.java)

}