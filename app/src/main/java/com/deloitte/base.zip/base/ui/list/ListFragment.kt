package com.deloitte.base.ui.list

import androidx.fragment.app.viewModels
import com.deloitte.base.databinding.FragmentListBinding
import com.deloitte.base.ui.base.BaseFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ListFragment : BaseFragment<FragmentListBinding>() {

    private val model by viewModels<ListViewModel>()

    override fun getViewBinding() = FragmentListBinding.inflate(layoutInflater)

    override fun setUpViews() {}
}